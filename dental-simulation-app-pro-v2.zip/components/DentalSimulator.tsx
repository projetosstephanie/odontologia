import React, { useRef, useState, useEffect } from "react";
import { useRouter } from "next/router";

const AFTER_SAMPLE_PATH = "/after-sample.jpg";

function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const reader = new FileReader();
    reader.onload = () => res(String(reader.result));
    reader.onerror = rej;
    reader.readAsDataURL(file);
  });
}

function applyAutoWhitening(img: HTMLImageElement, canvas: HTMLCanvasElement) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  canvas.width = img.naturalWidth;
  canvas.height = img.naturalHeight;
  ctx.drawImage(img, 0, 0);

  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;

  const brightness = 12;
  const contrast = 8;
  const whitenBoost = 10;
  const factor = (259 * (contrast + 255)) / (255 * (259 - contrast));

  for (let i = 0; i < data.length; i += 4) {
    let r = data[i];
    let g = data[i + 1];
    let b = data[i + 2];
    const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    const nearWhiteFactor = Math.min(1, Math.max(0, (lum - 160) / 95));
    r = r + brightness;
    g = g + brightness;
    b = b + brightness;
    r = factor * (r - 128) + 128;
    g = factor * (g - 128) + 128;
    b = factor * (b - 128) + 128;
    const desatAmount = 0.06;
    const avg = (r + g + b) / 3;
    r = r * (1 - desatAmount) + avg * desatAmount;
    g = g * (1 - desatAmount) + avg * desatAmount;
    b = b * (1 - desatAmount) + avg * desatAmount;
    if (nearWhiteFactor > 0) {
      r = r + whitenBoost * nearWhiteFactor;
      g = g + whitenBoost * nearWhiteFactor;
      b = b + whitenBoost * nearWhiteFactor;
    }
    data[i] = Math.max(0, Math.min(255, Math.round(r)));
    data[i + 1] = Math.max(0, Math.min(255, Math.round(g)));
    data[i + 2] = Math.max(0, Math.min(255, Math.round(b)));
  }
  ctx.putImageData(imageData, 0, 0);
}

export default function DentalSimulator() {
  const router = useRouter();
  const [images, setImages] = useState([{ id: '', src: '' }]);
  const [selectedId, setSelectedId] = useState(null);
  const [mode, setMode] = useState("auto");
  const [processing, setProcessing] = useState(false);
  const resultCanvasRef = useRef(null);
  const [resultSrc, setResultSrc] = useState(null);
  const [message, setMessage] = useState(null);

  // crop/pro controls simplified (we keep the pro version behavior already present)
  const [cropOpen, setCropOpen] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const imgRef = useRef(null);
  const frameRef = useRef(null);
  const [frame, setFrame] = useState({ x: 40, y: 40, w: 320, h: 240 });

  useEffect(()=>{
    if(message){
      const t = setTimeout(()=>setMessage(null), 3000);
      return ()=>clearTimeout(t);
    }
  },[message]);

  const handleFiles = async (files) => {
    if (!files) return;
    const list = Array.from(files).slice(0, 3);
    const readPromises = list.map(async (f, i) => ({ id: String(Date.now()) + i, src: await readFileAsDataURL(f), file: f }));
    const read = await Promise.all(readPromises);
    setImages((cur) => [...(cur || []).filter(Boolean).slice(0,0), ...read].slice(0, 3));
    if (!selectedId && read.length > 0) setSelectedId(read[0].id);
    setResultSrc(null);
  };

  const runSimulation = async () => {
    if (!selectedId) {
      setMessage("Selecione uma imagem primeiro.");
      return;
    }
    const selected = images.find((im) => im.id === selectedId);
    if (!selected) return;

    setProcessing(true);
    setResultSrc(null);

    const canvas = resultCanvasRef.current;

    if (mode === "static") {
      const afterImg = new Image();
      afterImg.crossOrigin = "anonymous";
      afterImg.src = AFTER_SAMPLE_PATH;
      await new Promise((res) => (afterImg.onload = res));

      const orig = new Image();
      orig.crossOrigin = "anonymous";
      orig.src = selected.src;
      await new Promise((res) => (orig.onload = res));

      const h = Math.max(orig.naturalHeight, afterImg.naturalHeight);
      const w = orig.naturalWidth + afterImg.naturalWidth;
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(orig, 0, 0);
      ctx.drawImage(afterImg, orig.naturalWidth, 0);

      const url = canvas.toDataURL("image/jpeg", 0.92);
      setResultSrc(url);
    } else {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = selected.src;
      await new Promise((res) => (img.onload = res));
      applyAutoWhitening(img, canvas);
      const url = canvas.toDataURL("image/jpeg", 0.92);
      setResultSrc(url);
    }

    setProcessing(false);
    setMessage("Simulação concluída com sucesso.");
  };

  const downloadResult = () => {
    if (resultSrc) {
      const a = document.createElement("a");
      a.href = resultSrc;
      a.download = "smile-simulation.jpg";
      a.click();
      return;
    }
    const canvas = resultCanvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL("image/jpeg", 0.9);
    const a = document.createElement("a");
    a.href = url;
    a.download = "smile-simulation.jpg";
    a.click();
  };

  const applyCropToSelected = () => {
    setCropOpen(false);
    setMessage("Recorte aplicado.");
  };

  const selected = images.find((x) => x.id === selectedId);

  return (
    <div className="p-6 max-w-5xl mx-auto bg-white rounded-lg shadow-sm">
      <h2 className="text-2xl font-semibold mb-2">Simulador Profissional — 4:3 (corrigido)</h2>
      <p className="mb-4 text-sm text-gray-600">Envie até 3 fotos, ajuste enquadramento e veja o antes/depois. (Página atualizada para corrigir exibição)</p>

      <input type="file" accept="image/*" multiple onChange={(e) => handleFiles(e.target.files)} className="block w-full text-sm text-gray-600 mb-4" />

      <div className="flex gap-3 mb-4 flex-wrap">
        {images.filter(Boolean).map((im) => (
          <button key={im.id} onClick={() => { setSelectedId(im.id); setCropOpen(false); setZoom(1); setOffset({ x: 0, y: 0 }); setResultSrc(null); }} className={`border rounded overflow-hidden w-28 h-28 ${selectedId === im.id ? "ring-2 ring-indigo-400" : ""}`}>
            <img src={im.src} alt="thumb" className="w-full h-full object-cover" />
          </button>
        ))}
      </div>

      <div className="flex items-center gap-3 mb-4">
        <label className="flex items-center gap-2"><input type="radio" checked={mode === 'auto'} onChange={() => setMode('auto')} /> Auto Filter</label>
        <label className="flex items-center gap-2"><input type="radio" checked={mode === 'static'} onChange={() => setMode('static')} /> Static Sample</label>
        <button onClick={() => setCropOpen(true)} disabled={!selectedId} className="px-3 py-2 border rounded">Abrir recorte</button>
        <button onClick={runSimulation} disabled={!selectedId || processing} className="px-4 py-2 bg-indigo-600 text-white rounded">{processing ? 'Processando...' : 'Gerar Simulação'}</button>
        <button onClick={downloadResult} className="px-3 py-2 border rounded">Baixar Resultado</button>
      </div>

      {message && <div className="mb-4 text-sm text-green-700">{message}</div>}

      {cropOpen && selected && (
        <div className="mb-4">
          <div className="mb-2 text-sm text-gray-500">Ferramenta de recorte (use os controles para ajustar). Clique em Aplicar recorte quando terminar.</div>
          <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
            <div style={{ position: 'relative', width: 480, height: 360, border: '1px solid #eee', overflow: 'hidden' }} ref={frameRef}>
              <div style={{ transform: `translate(${offset.x}px, ${offset.y}px) scale(${zoom})`, transformOrigin: 'top left', width: '100%', height: '100%', cursor: 'grab' }}
                onMouseDown={(e) => { (e.target).style.cursor = 'grabbing'; }}
                onMouseUp={(e) => { (e.target).style.cursor = 'grab'; }}
              >
                <img ref={imgRef} src={selected.src} alt="to-crop" style={{ display: 'block', userSelect: 'none', maxWidth: 'none', width: '100%', height: '100%', objectFit: 'cover' }} />
              </div>
            </div>

            <div style={{ minWidth: 160 }}>
              <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                <button onClick={() => setZoom(z => Math.min(3, +(z + 0.1).toFixed(2)))} className="px-3 py-2 border rounded">Zoom +</button>
                <button onClick={() => setZoom(z => Math.max(1, +(z - 0.1).toFixed(2)))} className="px-3 py-2 border rounded">Zoom -</button>
                <button onClick={() => { setZoom(1); setOffset({ x: 0, y: 0 }); }} className="px-3 py-2 border rounded">Reset</button>
              </div>
              <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                <button onClick={() => setOffset(o => ({ x: o.x - 20, y: o.y }))} className="px-3 py-2 border rounded">◀</button>
                <button onClick={() => setOffset(o => ({ x: o.x + 20, y: o.y }))} className="px-3 py-2 border rounded">▶</button>
                <button onClick={() => setOffset(o => ({ x: o.x, y: o.y - 20 }))} className="px-3 py-2 border rounded">▲</button>
                <button onClick={() => setOffset(o => ({ x: o.x, y: o.y + 20 }))} className="px-3 py-2 border rounded">▼</button>
              </div>
              <div>
                <button onClick={applyCropToSelected} className="px-3 py-2 bg-green-600 text-white rounded">Aplicar recorte 4:3</button>
                <button onClick={() => setCropOpen(false)} className="ml-2 px-3 py-2 border rounded">Cancelar</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        <div>
          <div className="text-xs text-gray-500 mb-1">Antes</div>
          {selected ? <img src={selected.src} className="w-full rounded shadow-sm" /> : <div className="w-full h-48 bg-gray-50 flex items-center justify-center text-gray-400">Nenhuma imagem</div>}
        </div>
        <div>
          <div className="text-xs text-gray-500 mb-1">Depois</div>
          <div className="w-full rounded shadow-sm bg-gray-50 p-2 min-h-[200px] flex items-center justify-center">
            {resultSrc ? <img src={resultSrc} alt="resultado" className="w-full object-contain" /> : <canvas ref={resultCanvasRef} style={{ maxWidth: '100%', height: 'auto', display: resultSrc ? 'none' : 'block' }} />}
          </div>
        </div>
      </div>
    </div>
  );
}
