import dynamic from 'next/dynamic';
const DentalSimulator = dynamic(() => import('../components/DentalSimulator'), { ssr: false });

export default function SimuladorPage(){
  return (
    <main style={{ minHeight: '100vh', background: '#f7f7fb', padding: '2rem' }}>
      <DentalSimulator />
    </main>
  )
}
