import { useEffect } from 'react';
import { useRouter } from 'next/router';

export default function Home(){
  const router = useRouter();
  useEffect(()=>{ router.replace('/simulador'); }, [router]);
  return <div style={{padding:40}}>Redirecionando para o simulador...</div>
}
